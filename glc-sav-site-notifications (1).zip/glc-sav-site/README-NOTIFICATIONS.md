# Notifications client WhatsApp/SMS

Cette version ajoute des boutons de notification client directement dans le détail d'un ticket de réparation.

## Fonctionnalités

- **Boutons dans la fiche ticket** : `Confirmation`, `Prêt`, `Facture`.
- **WhatsApp** : ouvre `wa.me` avec le message pré-rempli en français.
- **Numéros camerounais** : ajout automatique de l'indicatif `+237` si le numéro ne commence pas par `+`.
- **À la création d'un ticket** : une fenêtre WhatsApp de confirmation s'ouvre automatiquement avec le code de suivi du client.

## Modèles de messages

| Type | Message envoyé |
|------|----------------|
| reçu | Bonjour [nom]. Votre [appareil] a été reçu en atelier. Code de suivi : [code]. Suivi : [url] |
| pret | Bonjour [nom]. Votre [appareil] est prêt. Code : [code]. Passez à l'atelier. |
| facture | Bonjour [nom]. Votre [appareil] est réparé. Facture : [montant]. Code : [code]. |

## Déploiement

1. Déployer `index.html` et `app.js` sur Netlify (glisser-déposer ou CLI).
2. Si vous voulez tracer l'historique des notifications, exécuter `NOTIFICATIONS.sql` dans Supabase SQL Editor.

## Limites

- C'est une notification manuelle (1 clic = 1 message WhatsApp Web/App).
- Pour un envoi automatique/SMS payant, il faudra intégrer un provider (Twilio, Africa's Talking, etc.) via une serverless function.
