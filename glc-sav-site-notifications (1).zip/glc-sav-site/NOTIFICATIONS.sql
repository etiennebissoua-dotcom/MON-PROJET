-- Table optionnelle pour tracer les notifications envoyées
-- À exécuter dans Supabase → SQL Editor si vous voulez un historique.

-- Types de notification supportés par l'app
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_type WHERE typname = 'notification_type'
  ) THEN
    CREATE TYPE public.notification_type AS ENUM ('reçu', 'pret', 'facture');
  END IF;
END
$$;

CREATE TABLE IF NOT EXISTS public.notifications (
  id uuid primary key default gen_random_uuid(),
  reparation_id uuid references public.reparations(id) on delete cascade,
  client_id uuid references public.clients(id) on delete cascade,
  type public.notification_type not null,
  canal text not null default 'whatsapp',
  telephone text,
  message text not null,
  sent_at timestamp with time zone default now(),
  created_by uuid references auth.users(id) on delete set null
);

-- GRANT requis pour que l'API Supabase puisse lire/écrire
GRANT SELECT, INSERT, UPDATE, DELETE ON public.notifications TO authenticated;
GRANT ALL ON public.notifications TO service_role;
GRANT SELECT, UPDATE ON public.notifications TO anon;
GRANT USAGE, SELECT ON SEQUENCE public.notifications_id_seq TO authenticated;

-- RLS
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY IF NOT EXISTS "Staff can view all notifications"
  ON public.notifications
  FOR SELECT
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'technicien'));

CREATE POLICY IF NOT EXISTS "Staff can create notifications"
  ON public.notifications
  FOR INSERT
  TO authenticated
  WITH CHECK (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'technicien'));

-- Vue d'historique rapide
CREATE OR REPLACE VIEW public.v_notifications_recentes AS
SELECT n.*, c.nom as client_nom, r.code
FROM public.notifications n
LEFT JOIN public.clients c ON c.id = n.client_id
LEFT JOIN public.reparations r ON r.id = n.reparation_id
ORDER BY n.sent_at DESC;
